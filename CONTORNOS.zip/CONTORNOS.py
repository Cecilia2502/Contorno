import numpy as np
import cv2

original = cv2.imread("Psoriasis.jpg")
cv2.imshow("ORIGINAL", original)

gris = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)

G = cv2.GaussianBlur(gris, (5,5), 0)

cv2.imshow("TONOS GRISES", G)

canny = cv2.Canny(G, 50, 150)

cv2.imshow("CANNY", canny)
(contornos,_) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

print("ENCONTRE {} OBJETOS".format(len(contornos)))

cv2.drawContours(original,contornos,-1,(255,255,255),2)
cv2.imshow("PSORIASIS", original)
cv2.waitKey(0)
